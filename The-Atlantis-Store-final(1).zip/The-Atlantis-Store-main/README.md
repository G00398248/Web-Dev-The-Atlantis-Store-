# The-Atlantis-Store
Business Website Development


#mysql Database
Please use xampp-windows-x64-7.4.29-0-VC15 version to export / import database
Earlier version - xampp-windows-x64-8.1.5-0-VS16-installer - has an incompatibility between apache and php causing export functionality issues.
https://github.com/phpmyadmin/phpmyadmin/issues/17445