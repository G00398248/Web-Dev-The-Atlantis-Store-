<?php

// connecting to the database
require_once "config.php";
//require_once "session.php";


if($_SERVER["REQUEST_METHOD"]=="POST") {
	// Retrieve the variables
	$userNameReg = $_POST['usernameTxtReg'];
	$passwordReg = $_POST['passwordTxtReg'];

	// Insert details to the SQL Table
	$sqlQry = "INSERT INTO `tbl_user` (`fldUserName`, `fldPassword`) VALUES ('{$userNameReg}', '{$passwordReg}')";
	//echo $sqlQry;

	$result = mysqli_query($sqlConn, $sqlQry);

	if($result)
	{
		//echo "User has been registered";
		// After registeration, redirect the user to login Screen
		header("location: account.html");
	}
}
?>