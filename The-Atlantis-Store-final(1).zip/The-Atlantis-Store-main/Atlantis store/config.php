<?php
// Database credentials for mySQL root credentials
define('MYSQL_SERVER', 'localhost');
define('MYSQL_USERNAME', 'root');
define('MYSQL_PASSWORD', '');
define('DB_NAME', 'g00398248');
 
// Connect to the database 
$sqlConn = mysqli_connect(MYSQL_SERVER, MYSQL_USERNAME, MYSQL_PASSWORD, DB_NAME);
 
// On connection failure
if($sqlConn === false){
    die("MYSQL Server Connection Error: Could not connect. " . mysqli_connect_error());
}
?>