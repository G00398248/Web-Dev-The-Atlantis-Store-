<?php
// connecting to the database
require_once "config.php";

if($_SERVER["REQUEST_METHOD"]=="POST") {
	// Retrieve the variables
	$userName = $_POST['usernameTxt'];
	$password = $_POST['passwordTxt'];

    // Verify if the username and password exists 
	$sqlQry = "SELECT COUNT(*) as 'Count' FROM `tbl_user` WHERE `fldUserName`='{$userName}' AND `fldPassword`='{$password}'";
	//echo $sqlQry;

	// Convert the result into int for if loop
	$result = mysqli_query($sqlConn, $sqlQry);
    $row = mysqli_fetch_array($result);
    //echo $row['Count'];

	if($row['Count']>0)
	{
		//echo "User exists in the database.";
		// After login, redirect the user to cart Screen
		header("location: cart.html");
	}
    else{
        //echo "Login fails as User doesn't exist in the database.";
        // As Login fails, redirect the user to account Screen
        header("location: account.html");
    }
}
?>