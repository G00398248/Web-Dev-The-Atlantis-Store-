<?php
// Initiate the session
session_start();


if(isset($_SESSION("userName")) ){
    if($_SESSION("userName") === true){
        header("location: cart.html");
        exit;
    }
}
?>